1. install hyperledger: https://hyperledger.github.io/composer/installing/development-tools.html

2. run $ ./startFabric.sh

3. go into tutorial-network folder
	$ cd tutorial-network

4. run $ composer archive create -t dir -n .

5. run $ ./composer runtime install --card PeerAdmin@hlfv1 --businessNetworkName tutorial-network

6.  
